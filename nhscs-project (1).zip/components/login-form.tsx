"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { loginUser } from "@/lib/actions"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AlertCircle } from "lucide-react"

export function LoginForm() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const result = await loginUser(email, password)
      if (result.success) {
        router.push("/")
        router.refresh()
      } else {
        setError(result.error || "Invalid credentials")
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 border border-green-900 rounded-lg p-6 bg-black/50">
      <div className="space-y-2">
        <Label htmlFor="email" className="text-green-400">
          Email
        </Label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="bg-black border-green-900 text-green-400 focus:border-green-500 focus:ring-green-500"
          placeholder="your.email@example.com"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="password" className="text-green-400">
          Password
        </Label>
        <Input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="bg-black border-green-900 text-green-400 focus:border-green-500 focus:ring-green-500"
          placeholder="••••••••"
        />
      </div>

      {error && (
        <div className="flex items-center gap-2 text-red-500 text-sm">
          <AlertCircle className="h-4 w-4" />
          <p>{error}</p>
        </div>
      )}

      <Button type="submit" disabled={loading} className="w-full bg-green-900 hover:bg-green-800 text-white">
        {loading ? "Authenticating..." : "Login"}
      </Button>

      <div className="text-center text-sm">
        <p>
          Don&apos;t have an account?{" "}
          <Link href="/register" className="text-green-400 hover:underline">
            Register
          </Link>
        </p>
      </div>
    </form>
  )
}
