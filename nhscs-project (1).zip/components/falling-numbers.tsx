"use client"

import { useEffect, useRef } from "react"

export function FallingNumbers() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions to match parent
    const resizeCanvas = () => {
      const parent = canvas.parentElement
      if (parent) {
        canvas.width = parent.clientWidth
        canvas.height = parent.clientHeight
      }
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Matrix rain effect
    class Column {
      x: number
      speed: number
      fontSize: number
      text: string
      characters: string[]

      constructor(x: number, fontSize: number) {
        this.x = x
        this.speed = 1 + Math.random() * 3
        this.fontSize = fontSize
        this.characters = []

        // Generate random binary/hex characters
        const length = Math.floor(5 + Math.random() * 15)
        for (let i = 0; i < length; i++) {
          // Mix of 0s, 1s, and hex characters for cybersecurity feel
          const charPool = "01ABCDEF"
          this.characters.push(charPool.charAt(Math.floor(Math.random() * charPool.length)))
        }
      }

      draw(ctx: CanvasRenderingContext2D, canvasHeight: number, time: number) {
        // Cycle through different green shades
        const greenIntensity = Math.floor(150 + Math.sin(time / 1000 + this.x) * 50)

        for (let i = 0; i < this.characters.length; i++) {
          const y = (time * this.speed + i * this.fontSize) % canvasHeight

          // Fade out at the bottom
          const alpha = 1 - y / canvasHeight
          ctx.fillStyle = `rgba(0, ${greenIntensity}, 0, ${alpha})`

          // Highlight the first character
          if (i === 0) {
            ctx.fillStyle = `rgba(180, 255, 180, ${alpha})`
          }

          ctx.fillText(this.characters[i], this.x, y)

          // Occasionally change characters
          if (Math.random() < 0.005) {
            const charPool = "01ABCDEF"
            this.characters[i] = charPool.charAt(Math.floor(Math.random() * charPool.length))
          }
        }
      }
    }

    // Create columns
    const fontSize = 14
    const columns: Column[] = []
    const columnCount = Math.floor(canvas.width / fontSize)

    for (let i = 0; i < columnCount; i++) {
      columns.push(new Column(i * fontSize, fontSize))
    }

    // Animation loop
    let animationId: number
    const lastTime = 0

    const animate = (time: number) => {
      ctx.fillStyle = "rgba(0, 0, 0, 0.05)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      ctx.font = `${fontSize}px monospace`
      ctx.textAlign = "center"

      columns.forEach((column) => {
        column.draw(ctx, canvas.height, time)
      })

      animationId = requestAnimationFrame(animate)
    }

    animationId = requestAnimationFrame(animate)

    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener("resize", resizeCanvas)
    }
  }, [])

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
}
