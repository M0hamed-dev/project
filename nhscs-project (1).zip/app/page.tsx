import Link from "next/link"
import { redirect } from "next/navigation"
import { getSession } from "@/lib/session"
import { Button } from "@/components/ui/button"
import { FallingNumbers } from "@/components/falling-numbers"

export default async function Home() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="flex flex-col min-h-screen bg-black text-green-500">
      <header className="border-b border-green-900 p-4">
        <div className="container flex justify-between items-center">
          <h1 className="text-2xl font-bold tracking-wider">NHSCS_project</h1>
          <nav className="flex gap-4">
            <Link href="/dashboard">
              <Button variant="outline" className="border-green-500 text-green-500 hover:bg-green-900">
                Dashboard
              </Button>
            </Link>
            <Link href="/database">
              <Button variant="outline" className="border-green-500 text-green-500 hover:bg-green-900">
                View Database
              </Button>
            </Link>
            <form
              action={async () => {
                "use server"
                await clearSession()
                redirect("/login")
              }}
            >
              <Button type="submit" variant="outline" className="border-green-500 text-green-500 hover:bg-green-900">
                Logout
              </Button>
            </form>
          </nav>
        </div>
      </header>

      <main className="flex-1 container py-8">
        <div className="relative h-[60vh] overflow-hidden border border-green-900 rounded-lg mb-8">
          <FallingNumbers />
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-10">
            <div className="text-center max-w-2xl p-6 bg-black/80 border border-green-900 rounded-lg">
              <h2 className="text-3xl font-bold mb-4">Welcome to Cybersecurity Interface</h2>
              <p className="mb-4">
                This system demonstrates a secure 3-tier architecture with encrypted user authentication.
              </p>
              <p className="text-sm opacity-70">User: {session.email}</p>
            </div>
          </div>
        </div>

        <div className="border border-green-900 rounded-lg p-6 bg-black/50">
          <h2 className="text-2xl font-bold mb-4">Project Information</h2>
          <p className="mb-6">
            This is a network 2 project done by Boukhars Mohamed Amine, Boudjella Mohammed Amine, Bouzid Heithem, under
            the supervision of Dr. RIAHLA Mohamed Amine and Dr. MOUZAI Mustapha
          </p>

          <h3 className="text-xl font-bold mb-2">Project Team:</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
            {["Boukhars Mohamed Amine", "Boudjella Mohammed Amine", "Bouzid Heithem"].map((name) => (
              <div key={name} className="border border-green-900 rounded-lg p-4 text-center">
                <p className="font-bold mb-2">{name}</p>
                <p className="text-sm">NHSCS student</p>
              </div>
            ))}
          </div>
        </div>
      </main>

      <footer className="border-t border-green-900 p-4 text-center text-sm">
        <p>© 2025 NHSCS_project - All rights reserved</p>
      </footer>
    </div>
  )
}

async function clearSession() {
  "use server"
  const cookies = (await import("next/headers")).cookies
  cookies().delete("session")
}
