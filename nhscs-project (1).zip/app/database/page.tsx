import { redirect } from "next/navigation"
import { getSession } from "@/lib/session"
import { getAllUsers } from "@/lib/actions"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Database, Shield, User } from "lucide-react"

export default async function DatabasePage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  const users = await getAllUsers()

  return (
    <div className="flex flex-col min-h-screen bg-black text-green-500">
      <header className="border-b border-green-900 p-4">
        <div className="container flex justify-between items-center">
          <h1 className="text-2xl font-bold tracking-wider">NHSCS_project</h1>
          <nav className="flex gap-4">
            <Button variant="outline" className="border-green-500 text-green-500 hover:bg-green-900" asChild>
              <a href="/">Home</a>
            </Button>
            <Button variant="outline" className="border-green-500 text-green-500 hover:bg-green-900" asChild>
              <a href="/dashboard">Dashboard</a>
            </Button>
            <form
              action={async () => {
                "use server"
                const cookies = (await import("next/headers")).cookies
                cookies().delete("session")
                redirect("/login")
              }}
            >
              <Button type="submit" variant="outline" className="border-green-500 text-green-500 hover:bg-green-900">
                Logout
              </Button>
            </form>
          </nav>
        </div>
      </header>

      <main className="flex-1 container py-8">
        <div className="flex items-center gap-3 mb-8">
          <Database className="h-8 w-8 text-green-400" />
          <h2 className="text-3xl font-bold">Database Visualization</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-black border-green-900">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-green-400" />
                Total Users
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{users.length}</p>
              <p className="text-sm text-green-400 mt-1">Registered accounts</p>
            </CardContent>
          </Card>

          <Card className="bg-black border-green-900">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-green-400" />
                Database Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">Secure</p>
              <p className="text-sm text-green-400 mt-1">Encrypted storage</p>
            </CardContent>
          </Card>

          <Card className="bg-black border-green-900">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-green-400" />
                Database Type
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">Secure Storage</p>
              <p className="text-sm text-green-400 mt-1">3-tier architecture</p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-black border-green-900 mb-8">
          <CardHeader>
            <CardTitle>Database Schema</CardTitle>
            <CardDescription className="text-green-400">User Table Structure</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="p-4 border border-green-900 rounded-lg overflow-hidden">
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <h3 className="font-bold mb-2 text-green-400">Users Table</h3>
                  <ul className="space-y-1 text-sm">
                    <li>
                      <span className="text-yellow-400">id</span>: INTEGER PRIMARY KEY
                    </li>
                    <li>
                      <span className="text-yellow-400">email</span>: VARCHAR(255) UNIQUE
                    </li>
                    <li>
                      <span className="text-yellow-400">passwordHash</span>: VARCHAR(255)
                    </li>
                    <li>
                      <span className="text-yellow-400">createdAt</span>: TIMESTAMP
                    </li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-bold mb-2 text-green-400">Sessions Table</h3>
                  <ul className="space-y-1 text-sm">
                    <li>
                      <span className="text-yellow-400">id</span>: INTEGER PRIMARY KEY
                    </li>
                    <li>
                      <span className="text-yellow-400">userId</span>: INTEGER FOREIGN KEY
                    </li>
                    <li>
                      <span className="text-yellow-400">token</span>: VARCHAR(255)
                    </li>
                    <li>
                      <span className="text-yellow-400">expiresAt</span>: TIMESTAMP
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-black border-green-900">
          <CardHeader>
            <CardTitle>User Records</CardTitle>
            <CardDescription className="text-green-400">Registered users in the database</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="border border-green-900 rounded-lg overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-green-900">
                    <TableHead className="text-green-400">ID</TableHead>
                    <TableHead className="text-green-400">Email</TableHead>
                    <TableHead className="text-green-400">Password</TableHead>
                    <TableHead className="text-green-400">Created At</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id} className="border-green-900">
                      <TableCell className="font-mono">{user.id}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <span className="font-mono bg-green-900/30 px-2 py-1 rounded text-xs">
                          {/* Show masked password for security */}
                          ••••••••••••••••
                        </span>
                      </TableCell>
                      <TableCell>{new Date(user.createdAt).toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>

      <footer className="border-t border-green-900 p-4 text-center text-sm">
        <p>© 2025 NHSCS_project - All rights reserved</p>
      </footer>
    </div>
  )
}
