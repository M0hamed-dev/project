import { redirect } from "next/navigation"
import { RegisterForm } from "@/components/register-form"
import { getSession } from "@/lib/session"

export default async function RegisterPage() {
  const session = await getSession()

  if (session) {
    redirect("/")
  }

  return (
    <div className="min-h-screen flex flex-col bg-black text-green-500">
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold tracking-wider mb-2">NHSCS_project</h1>
            <p className="text-green-400 opacity-80">Create Secure Account</p>
          </div>

          <RegisterForm />

          <div className="mt-8 text-center text-sm opacity-70">
            <p>This is a network 2 project done by:</p>
            <p className="mt-2">Boukhars Mohamed Amine, Boudjella Mohammed Amine, Bouzid Heithem</p>
            <p className="mt-2">Under the supervision of Dr. RIAHLA Mohamed Amine and Dr. MOUZAI Mustapha</p>
          </div>
        </div>
      </div>
    </div>
  )
}
