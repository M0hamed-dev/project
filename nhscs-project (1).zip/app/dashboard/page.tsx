import { redirect } from "next/navigation"
import { getSession } from "@/lib/session"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Lock, AlertTriangle, FileText } from "lucide-react"

export default async function DashboardPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="flex flex-col min-h-screen bg-black text-green-500">
      <header className="border-b border-green-900 p-4">
        <div className="container flex justify-between items-center">
          <h1 className="text-2xl font-bold tracking-wider">NHSCS_project</h1>
          <nav className="flex gap-4">
            <Button variant="outline" className="border-green-500 text-green-500 hover:bg-green-900" asChild>
              <a href="/">Home</a>
            </Button>
            <Button variant="outline" className="border-green-500 text-green-500 hover:bg-green-900" asChild>
              <a href="/database">View Database</a>
            </Button>
            <form
              action={async () => {
                "use server"
                const cookies = (await import("next/headers")).cookies
                cookies().delete("session")
                redirect("/login")
              }}
            >
              <Button type="submit" variant="outline" className="border-green-500 text-green-500 hover:bg-green-900">
                Logout
              </Button>
            </form>
          </nav>
        </div>
      </header>

      <main className="flex-1 container py-8">
        <h2 className="text-3xl font-bold mb-8">Cybersecurity Dashboard</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black border-green-900">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-green-400" />
                Security Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">Protected</p>
              <p className="text-sm text-green-400 mt-1">All systems secure</p>
            </CardContent>
          </Card>

          <Card className="bg-black border-green-900">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-yellow-400" />
                Authentication
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">Active</p>
              <p className="text-sm text-green-400 mt-1">Last login: Now</p>
            </CardContent>
          </Card>

          <Card className="bg-black border-green-900">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-400" />
                Threats Detected
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">0</p>
              <p className="text-sm text-green-400 mt-1">System clean</p>
            </CardContent>
          </Card>

          <Card className="bg-black border-green-900">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-blue-400" />
                Security Logs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">24</p>
              <p className="text-sm text-green-400 mt-1">Events today</p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-black border-green-900 mb-8">
          <CardHeader>
            <CardTitle>Network Architecture</CardTitle>
            <CardDescription className="text-green-400">3-Tier Security Implementation</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="p-4 border border-green-900 rounded-lg">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div className="p-4 border border-green-900 rounded-lg">
                  <h3 className="font-bold mb-2">Client Tier</h3>
                  <p className="text-sm">User interface with secure authentication</p>
                </div>
                <div className="p-4 border border-green-900 rounded-lg">
                  <h3 className="font-bold mb-2">Application Tier</h3>
                  <p className="text-sm">Business logic and security processing</p>
                </div>
                <div className="p-4 border border-green-900 rounded-lg">
                  <h3 className="font-bold mb-2">Data Tier</h3>
                  <p className="text-sm">Encrypted user data storage</p>
                </div>
              </div>

              <div className="mt-6 text-sm">
                <p>This 3-tier architecture ensures:</p>
                <ul className="list-disc pl-5 mt-2 space-y-1">
                  <li>Separation of concerns for enhanced security</li>
                  <li>Password hashing and secure storage</li>
                  <li>Protected communication between layers</li>
                  <li>Defense in depth strategy</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="border border-green-900 rounded-lg p-6 bg-black/50">
          <h2 className="text-2xl font-bold mb-4">Project Information</h2>
          <p className="mb-6">
            This is a network 2 project done by Boukhars Mohamed Amine, Boudjella Mohammed Amine, Bouzid Heithem, under
            the supervision of Dr. RIAHLA Mohamed Amine and Dr. MOUZAI Mustapha
          </p>

          <h3 className="text-xl font-bold mb-2">Project Team:</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
            {["Boukhars Mohamed Amine", "Boudjella Mohammed Amine", "Bouzid Heithem"].map((name) => (
              <div key={name} className="border border-green-900 rounded-lg p-4 text-center">
                <p className="font-bold mb-2">{name}</p>
                <p className="text-sm">NHSCS student</p>
              </div>
            ))}
          </div>
        </div>
      </main>

      <footer className="border-t border-green-900 p-4 text-center text-sm">
        <p>© 2025 NHSCS_project - All rights reserved</p>
      </footer>
    </div>
  )
}
