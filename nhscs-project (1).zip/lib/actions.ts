"use server"
import { createSession } from "@/lib/session"
import { db } from "@/lib/db"

// Login action
export async function loginUser(email: string, password: string) {
  try {
    // Find user in database
    const user = await db.findUserByEmail(email)

    if (!user) {
      return { success: false, error: "Invalid email or password" }
    }

    // Verify password
    const isPasswordValid = await db.verifyPassword(user.id, password)

    if (!isPasswordValid) {
      return { success: false, error: "Invalid email or password" }
    }

    // Create session
    await createSession(user.id, user.email)

    return { success: true }
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, error: "An error occurred during login" }
  }
}

// Register action
export async function registerUser(email: string, password: string) {
  try {
    // Check if user already exists
    const existingUser = await db.findUserByEmail(email)

    if (existingUser) {
      return { success: false, error: "Email already in use" }
    }

    // Create new user
    const userId = await db.createUser(email, password)

    // Create session
    await createSession(userId, email)

    return { success: true }
  } catch (error) {
    console.error("Registration error:", error)
    return { success: false, error: "An error occurred during registration" }
  }
}

// Get all users (for database visualization)
export async function getAllUsers() {
  try {
    // Get all users from the database
    const allUsers = await db.getAllUsers()
    return allUsers
  } catch (error) {
    console.error("Error fetching users:", error)
    return []
  }
}
