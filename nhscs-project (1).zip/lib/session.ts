"use server"

import { cookies } from "next/headers"
import { encrypt, decrypt } from "@/lib/crypto"

// Create a new session
export async function createSession(userId: number, email: string) {
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days

  // Create session data
  const sessionData = {
    userId,
    email,
    expiresAt: expiresAt.toISOString(),
  }

  // Encrypt session data
  const encryptedSession = await encrypt(JSON.stringify(sessionData))

  // Store in cookie
  cookies().set("session", encryptedSession, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    expires: expiresAt,
    sameSite: "lax",
    path: "/",
  })
}

// Get current session
export async function getSession() {
  const sessionCookie = cookies().get("session")

  if (!sessionCookie) {
    return null
  }

  try {
    // Decrypt session
    const decrypted = await decrypt(sessionCookie.value)
    if (!decrypted) return null

    const sessionData = JSON.parse(decrypted)

    // Check if session is expired
    if (new Date(sessionData.expiresAt) < new Date()) {
      cookies().delete("session")
      return null
    }

    return sessionData
  } catch (error) {
    console.error("Session error:", error)
    cookies().delete("session")
    return null
  }
}
