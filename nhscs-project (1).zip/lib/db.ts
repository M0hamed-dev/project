"use server"

// Simulated database for demonstration purposes
// In a real application, you would use a proper database like PostgreSQL, MySQL, etc.

interface User {
  id: number
  email: string
  passwordHash: string
  createdAt: string
}

// In-memory database for demonstration
const users: User[] = [
  {
    id: 1,
    email: "admin@nhscs.edu",
    // This would be a properly hashed password in a real application
    passwordHash: "hashed_password_for_admin123",
    createdAt: new Date().toISOString(),
  },
]

let nextUserId = 2

// Simple password hashing (for demo purposes only)
// In a real app, use bcrypt or Argon2
async function hashPassword(password: string): Promise<string> {
  // This is NOT secure - just for demonstration
  return `hashed_password_for_${password}`
}

// Database operations
export const db = {
  // Find user by email
  async findUserByEmail(email: string): Promise<User | undefined> {
    return users.find((user) => user.email === email)
  },

  // Verify password
  async verifyPassword(userId: number, password: string): Promise<boolean> {
    const user = users.find((user) => user.id === userId)
    if (!user) return false

    // In a real app, use proper password comparison
    const hashedInput = await hashPassword(password)
    return user.passwordHash === hashedInput
  },

  // Create new user
  async createUser(email: string, password: string): Promise<number> {
    const passwordHash = await hashPassword(password)

    const newUser: User = {
      id: nextUserId++,
      email,
      passwordHash,
      createdAt: new Date().toISOString(),
    }

    users.push(newUser)
    return newUser.id
  },

  // Get all users
  async getAllUsers(): Promise<User[]> {
    // Return a copy of the users array to prevent modification
    return [...users]
  },
}
